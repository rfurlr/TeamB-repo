# TeamB
Embedded C Team B
